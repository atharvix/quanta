# System Requirements — QUANTA

> **Document Status:** Phase 0 Draft — Pending Review  
> **Scope:** Functional, Non-Functional, Financial Correctness, and Operational Requirements.

---

## 1. Functional Requirements

### 1.1 Treasury & Balance Management (Go Core)
- **FR-01 (Authoritative Ledger):** The system shall maintain authoritative records of treasury accounts, balances, holds/encumbrances, and available balances in PostgreSQL.
- **FR-02 (Liquidity Partitioning):** The system shall explicitly separate total funds into **Operating Liquidity**, **Emergency Reserves**, and **Investable Capital** according to configurable policy thresholds.
- **FR-03 (Counterparty Exposure Tracking):** The system shall track capital exposure per counterparty and enforce configurable exposure caps.
- **FR-04 (Financial Constraints Registry):** Treasury analysts/approvers shall be able to define explicit constraints (minimum operating liquidity, emergency reserve floor, counterparty caps, horizon limits, and concentration limits).

### 1.2 Forecasting, Risk & Optimization (Python Intelligence + Go Verification)
- **FR-05 (Cash-Flow Forecasting):** The intelligence service shall generate cash-flow forecasts with uncertainty bounds over configurable horizons from synthetic treasury histories.
- **FR-06 (Risk & Stress Simulation):** The intelligence service shall compute risk metrics (including VaR, CVaR, Monte Carlo distributions, stress scenarios, and anomaly flags) for current and proposed portfolios.
- **FR-07 (Constrained Optimization):** The intelligence service shall solve capital allocation optimization problems and explicitly report feasibility status, objective value, solver runtime, and any violated or binding constraints.
- **FR-08 (Classical vs. Quantum Benchmarking):** Any quantum or quantum-inspired solver evaluation shall run alongside a classical baseline on the identical problem instance and report comparative metrics without assuming quantum advantage.
- **FR-09 (Independent Go Verification):** The Go backend shall independently re-verify arithmetic balance conservation and hard constraint satisfaction on any allocation returned by Python before persisting or presenting it as feasible.

### 1.3 Semi-Autonomous Governance & Auditability
- **FR-10 (Approval Workflow):** Consequential financial actions (e.g., adopting an allocation recommendation, releasing emergency reserves, altering policy limits) shall enter a formal state machine (`DRAFT` → `PENDING_APPROVAL` → `APPROVED` / `REJECTED` / `EXPIRED`) requiring an authorized human approver.
- **FR-11 (Maker-Checker Separation):** The user who submits a consequential financial recommendation for approval shall not be permitted to approve that same action. *(Proposed default rule; see Security Model.)*
- **FR-12 (Immutable Audit Trail):** Every state mutation, recommendation generation, solver failure, approval decision, and policy change shall emit an append-only audit record capturing actor, timestamp, inputs/snapshot reference, and outcome.

### 1.4 Synthetic Data & Explainability
- **FR-13 (Deterministic Synthetic Data):** The platform shall support seeded, reproducible synthetic treasury datasets for testing and demonstration without external integrations.
- **FR-14 (Non-Authoritative Language Explanations):** Optional natural-language explanations of optimization or risk reports shall cite only Go/Python-verified numbers and shall never compute or alter numerical metrics.

---

## 2. Non-Functional Requirements

### 2.1 Financial Correctness & Precision
- **NFR-01 (No Binary Float Storage):** Authoritative monetary values shall **never** use ordinary binary floating-point types (`float32`/`float64` in Go, `REAL`/`DOUBLE PRECISION` in SQL). PostgreSQL shall use fixed-point `NUMERIC`, and Go shall use exact decimal or scaled integer arithmetic.
- **NFR-02 (Explicit Rounding & Reconciliation):** Rounding rules (mode, precision, and residual handling) shall be explicit, deterministic, and covered by automated unit tests verifying conservation of capital.
- **NFR-03 (Fail-Safe Solver Degradation):** Solver timeouts, numerical non-convergence, or infeasibility shall never silently produce an invalid allocation; they shall return structured failure/infeasibility diagnostics and preserve the last valid treasury state.

### 2.2 Architecture & Platform Constraints
- **NFR-04 (Native Windows Execution):** All services (Go backend, Python intelligence service, native PostgreSQL, and future TypeScript/Svelte frontend) shall run natively on Windows without Docker, Docker Compose, or Kubernetes.
- **NFR-05 (Modular Monolith Discipline):** Core financial domains in Go shall remain cleanly separated in internal modules with explicit interfaces rather than premature microservices.
- **NFR-06 (Explicit Cross-Language Contracts):** All communication between Go and Python shall conform to versioned, validated schemas with correlation IDs and strict timeouts.

### 2.3 Reliability, Security & Observability
- **NFR-07 (Transactional Integrity):** Balance updates, reserve locks, approval transitions, and corresponding audit log entries shall commit atomically within PostgreSQL ACID transactions.
- **NFR-08 (Structured Logging & Traceability):** Every request shall carry a correlation ID propagated from the Go gateway to the Python intelligence service and recorded in audit/diagnostic logs.

---

## 3. Decision Summary

| Requirement Area | Classification | Notes |
| :--- | :--- | :--- |
| Exact decimal arithmetic & Go-side constraint verification | **Confirmed** | Core correctness pillar |
| Semi-autonomous human approval gate for consequential actions | **Confirmed** | No autonomous money movement |
| Native Windows + PowerShell execution without containers | **Confirmed** | Excludes Docker/K8s |
| Maker-checker separation on all approvals | **Proposed** | Needs confirmation for single-admin dev ergonomics vs strict prod mode |

## 4. Unresolved Questions

1. What maximum response-time SLA should apply to synchronous optimization/simulation calls vs. asynchronous background jobs?
2. Should `EXPIRED` recommendations invalidate automatically after a fixed time window or whenever underlying account balances change by more than a threshold?
3. Should audit logs include full serialized input/output payloads inline or reference immutable snapshot records to control table growth?
