# API & Contract Design — QUANTA

> **Document Status:** Phase 0 Draft — Pending Review  
> **Scope:** External REST API (Go Gateway) and Explicit Internal Go ↔ Python Contracts.

---

## 1. API Architectural Boundary

- **External Clients (Future TypeScript/Svelte UI, CLI, Smoke Tests)** communicate **only** with the **Go Modular Monolith** over HTTPS/HTTP REST JSON.
- **Go ↔ Python Internal Boundary** uses an explicit, versioned contract over localhost (`127.0.0.1`). Clients never bypass Go to call Python directly in production workflows.
- **Correlation Tracking:** Go generates or propagates `X-Correlation-ID` on every inbound request and passes it to Python and PostgreSQL audit logs.

---

## 2. External REST API Surface (Go Core — Proposed)

Base prefix: `/api/v1`

### 2.1 System & Authentication
- `GET /api/v1/health` — Readiness check reporting Go, PostgreSQL, and Python intelligence reachability.
- `POST /api/v1/auth/login` — Authenticate and issue session/token.
- `GET /api/v1/auth/me` — Inspect authenticated user profile and RBAC role.

### 2.2 Treasury, Balances & Constraints
- `GET /api/v1/treasuries` / `POST /api/v1/treasuries` — List or create synthetic treasury entities.
- `GET /api/v1/treasuries/{id}/position` — Authoritative position breakdown: `ledger_balance`, `encumbered_balance`, `available_balance`, `operating_liquidity`, `emergency_reserves`, `investable_capital`.
- `GET /api/v1/treasuries/{id}/counterparties` / `POST ...` — Manage counterparty exposure limits.
- `GET /api/v1/treasuries/{id}/constraints` / `POST ...` — Manage hard/soft financial constraints.

### 2.3 Intelligence Triggers (Go → Python → Go Verification)
- `POST /api/v1/treasuries/{id}/forecast` — Trigger cash-flow forecast and persist snapshot.
- `POST /api/v1/treasuries/{id}/risk/evaluate` — Trigger VaR, CVaR, Monte Carlo, and stress-test evaluation.
- `POST /api/v1/treasuries/{id}/optimize` — Trigger constrained optimization (classical and/or quantum benchmark), verify results in Go, and create a `DRAFT` `AllocationProposal`.

### 2.4 Governance, Approvals & Audit
- `POST /api/v1/proposals/{id}/submit` — Move `DRAFT` → `PENDING_APPROVAL` (Analyst).
- `POST /api/v1/proposals/{id}/approve` — Re-verify live balances/constraints and transition `PENDING_APPROVAL` → `APPROVED` (Approver, maker-checker enforced).
- `POST /api/v1/proposals/{id}/reject` — Transition `PENDING_APPROVAL` → `REJECTED` with mandatory rationale.
- `GET /api/v1/audit-events` — Paginated, filterable audit trail (Auditor / Admin).

---

## 3. Explicit Go ↔ Python Contract Specification

**Confirmed Decision:** All Go ↔ Python payloads are explicitly typed, versioned (`contract_version: "1.0"`), and treat monetary amounts as **exact decimal strings** (never raw floats) across the wire.

### 3.1 Contract Envelope (Common Fields)
- `contract_version` (`string`): `"1.0"`
- `correlation_id` (`string`): Trace UUID from Go
- `seed` (`integer | null`): Deterministic seed for reproducible synthetic/stochastic runs

### 3.2 Optimization Request (`POST /internal/v1/optimize`)
Sent by Go after computing authoritative `investable_capital`:
```json
{
  "contract_version": "1.0",
  "correlation_id": "uuid",
  "treasury_id": "uuid",
  "investable_capital": "750000.0000",
  "operating_liquidity_floor": "150000.0000",
  "emergency_reserve_floor": "100000.0000",
  "risk_tolerance": "0.500000",
  "candidates": [
    {
      "id": "bucket_a",
      "counterparty_id": "cp_1",
      "expected_return": "0.065000",
      "risk": "0.040000",
      "liquidity_factor": "0.950000",
      "min_allocation": "0.0000",
      "max_allocation": "300000.0000"
    }
  ],
  "counterparty_limits": [
    {
      "counterparty_id": "cp_1",
      "current_exposure": "50000.0000",
      "max_exposure_limit": "350000.0000"
    }
  ],
  "solver_mode": "classical_and_quantum_benchmark",
  "timeout_ms": 15000
}
```

### 3.3 Optimization Response
Returned by Python as a **non-authoritative candidate** for Go verification:
```json
{
  "contract_version": "1.0",
  "correlation_id": "uuid",
  "status": "COMPLETED",
  "feasible": true,
  "solver_used": "highs_lp",
  "allocations": {
    "bucket_a": "250000.0000"
  },
  "unallocated_cash": "500000.0000",
  "metrics": {
    "expected_return": "0.052000",
    "portfolio_risk": "0.021000",
    "post_allocation_liquidity": "0.960000"
  },
  "benchmark_comparison": [],
  "constraint_violations": [],
  "warnings": [],
  "runtime_ms": 18
}
```
- **Infeasible Case:** `status: "COMPLETED"`, `feasible: false`, `constraint_violations: [...]`, empty allocations.
- **Failure Case:** `status: "SOLVER_FAILED"`, `error_code`, `error_message` (Go maps cleanly without mutating treasury state).

### 3.4 Forecast & Risk Contracts (Proposed)
- `POST /internal/v1/forecast`: Accepts historical synthetic cash-flow series (decimal strings + timestamps), horizon length, and candidate model list; returns point forecasts + quantile intervals (`p10`, `p50`, `p90`) + model metadata.
- `POST /internal/v1/risk/evaluate`: Accepts current/proposed allocations, covariance/scenario parameters, confidence levels, and stress scenarios; returns VaR, CVaR, stress-test losses, and anomaly flags.
- `POST /internal/v1/explain` *(Optional, Non-Authoritative)*: Accepts Go-verified numeric summaries only and returns narrative commentary tagged `authoritative: false`.

---

## 4. Decision Summary & Unresolved Questions

| Item | Classification | Notes |
| :--- | :--- | :--- |
| Go owns external API; Python is internal-only | **Confirmed** | Enforces governance & verification |
| Decimal strings across Go ↔ Python JSON wire | **Confirmed** | Prevents JSON float precision drift |
| REST JSON over `http://127.0.0.1` for Phase 1 | **Proposed** | gRPC remains a future option if needed |

**Unresolved Questions:**
1. Should Go ↔ Python use a shared HMAC/bearer internal token even on `127.0.0.1`?
2. Should `timeout_ms` vary by endpoint (e.g., 5s for single LP vs. 30s for Monte Carlo / QAOA benchmarks)?
