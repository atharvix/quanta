# Domain Model & Financial Correctness Specification — QUANTA

> **Document Status:** Phase 0 Draft — Pending Review  
> **Purpose:** Define authoritative treasury entities, monetary representation, liquidity partitioning, constraint semantics, and governance lifecycles.

---

## 1. Core Financial Entities (Authoritative in Go + PostgreSQL)

```
+----------------------+       1..*       +------------------------+
|   TreasuryEntity     |----------------->|    TreasuryAccount     |
+----------------------+                  +------------------------+
          |                                           |
          | 1..*                                      | 1..*
          v                                           v
+----------------------+                  +------------------------+
|  FinancialConstraint |                  |     LedgerEntry        |
+----------------------+                  +------------------------+
          |                                           |
          v                                           v
+----------------------+       1..*       +------------------------+
|  OptimizationRun     |----------------->|  AllocationProposal    |
+----------------------+                  +------------------------+
          |                                           |
          |                                           v
          |                               +------------------------+
          +------------------------------>|    ApprovalDecision    |
                                          +------------------------+
```

### Entity Definitions
1. **TreasuryEntity:** Top-level corporate treasury unit owning accounts, reserve policies, constraints, and counterparty limits.
2. **TreasuryAccount:** A logical or synthetic cash/holding account belonging to a `TreasuryEntity`, denominated in an explicit currency code with `ledger_balance` and `encumbered_balance` (pending/reserved holds).
3. **Counterparty:** An external institution or obligor against which exposure is measured and capped.
4. **LedgerEntry:** An append-only monetary movement or reservation event recording exact delta, resulting balance, correlation ID, and reason.
5. **LiquidityPolicy:** Explicit rules defining required **Operating Liquidity** and **Emergency Reserves** for a `TreasuryEntity`.
6. **FinancialConstraint:** A named, typed, versioned rule (hard or soft) applied to optimization and risk checks.
7. **OptimizationRun:** A recorded invocation of the Python intelligence service capturing problem snapshot hash, solver candidates executed, feasibility status, runtime, and raw output.
8. **AllocationProposal:** A Go-verified, human-readable capital allocation recommendation derived from an `OptimizationRun`, subject to approval workflow transitions.
9. **ApprovalDecision:** An immutable human decision (`APPROVE`, `REJECT`) attached to a `PENDING_APPROVAL` proposal or policy mutation.
10. **AuditEvent:** An append-only record of every security-relevant or financially consequential event.

---

## 2. Monetary Representation, Precision & Rounding Rules

### 2.1 Representation Rules
- **Confirmed Decision:** Ordinary floating-point types (`float32`, `float64`, `REAL`, `DOUBLE PRECISION`) **must never** be used for authoritative monetary storage, balance tracking, or ledger arithmetic.
- **Proposed Decision:**
  - **PostgreSQL Storage:**
    - Monetary balances, limits, and allocation amounts: `NUMERIC(20, 4)` (supports up to 16 integer digits and 4 fractional digits, avoiding rounding drift in sub-unit calculations).
    - Rates, returns, probabilities, risk weights, and fractions: `NUMERIC(12, 6)`.
  - **Go Domain Layer:** Represent monetary values using a dedicated decimal value type (or scaled `int64` minor units paired with explicit scale metadata), never native `float64`.
  - **Python Intelligence Boundary:** Serialize monetary values over JSON as **decimal strings** (e.g., `"1000000.0000"`) or exact integer minor units when crossing the Go ↔ Python boundary. Python converts inputs to `decimal.Decimal` at ingestion; where numerical solvers (LP/QP/QAOA) internally require `numpy`/`float64`, Python converts back and **Go performs final decimal quantization and exact-sum reconciliation**.

### 2.2 Rounding & Reconciliation Rules (Proposed)
- **Rounding Mode:** **Round Half to Even (Banker's Rounding)** when quantizing continuous solver weights into target monetary precision.
- **Conservation Invariant:** For every allocation across $n$ targets plus unallocated cash $C_{\text{cash}}$:
  $$\sum_{i=1}^{n} A_i + C_{\text{cash}} + R_{\text{emergency}} + L_{\text{operating}} = B_{\text{available\_total}}$$
- **Residual Assignment:** Any sub-unit quantization remainder $\epsilon = B_{\text{target}} - \sum_i \text{round}(A_i)$ is explicitly assigned to `unallocated_cash` (or adjusted on the highest-liquidity cash bucket) and logged, ensuring **zero silent penny/unit leakage**.

---

## 3. Balance & Liquidity Definitions

All quantities below are defined explicitly so both Go domain rules and Python solvers operate on identical semantics:

| Concept | Formal Definition | Testable Invariant |
| :--- | :--- | :--- |
| **Account Balance (`ledger_balance`)** | Total recorded funds in an account from committed ledger entries. | `ledger_balance >= 0` (unless explicit overdraft facility is modeled) |
| **Encumbered / Reserved Balance (`encumbered_balance`)** | Funds earmarked for pending obligations, approved commitments, or active holds. | `0 <= encumbered_balance <= ledger_balance` |
| **Available Balance (`available_balance`)** | Unencumbered funds immediately accessible: `ledger_balance - encumbered_balance`. | `available_balance >= 0` |
| **Operating Liquidity ($L_{\text{op}}$)** | Minimum liquid capital required to cover near-term working capital / operational outflows over the configured operating buffer window. | `L_op >= policy.min_operating_liquidity` |
| **Emergency Reserves ($R_{\text{em}}$)** | Ring-fenced crisis buffer not eligible for risky deployment; releasable only via explicit human approval. | `R_em >= policy.min_emergency_reserve` |
| **Investable Capital ($C_{\text{inv}}$)** | Capital eligible for optimization deployment: `max(0, sum(available_balance) - L_op - R_em)`. | `sum(proposed_allocations) <= C_inv` |

---

## 4. Financial Constraints & Counterparty Exposure

### 4.1 Constraint Taxonomy
- **Hard Constraints (Must be satisfied for feasibility):**
  1. Capital budget conservation (`allocated <= investable_capital`).
  2. Operating liquidity floor (`post_allocation_liquid_funds >= L_op`).
  3. Emergency reserve preservation (`R_em` untouched unless explicit reserve-release approval exists).
  4. Per-counterparty exposure ceiling (`exposure(counterparty_k) <= cap_k`).
  5. Asset-class or bucket exposure ceiling (`exposure(class_g) <= cap_g`).
- **Soft Constraints (Penalized in objective if violated, flagged in report):**
  - Target diversification / concentration (e.g., HHI ceiling).
  - Minimum ticket size / turnover preferences.

### 4.2 Counterparty Exposure
- **Confirmed Decision:** Counterparty exposure aggregates all active holdings, pending approved proposals, and committed facilities linked to a `Counterparty` ID across all accounts of a `TreasuryEntity`.
- **Testable Invariant:** Before any proposal can transition to `APPROVED`, Go re-evaluates `current_exposure + proposed_delta <= counterparty.max_exposure_limit`.

---

## 5. Optimization Feasibility, Solver Failures & Approval Workflows

### 5.1 Optimization Feasibility & Solver Failures
- **Feasible:** A solution satisfies all hard constraints within a tiny numerical solver tolerance (`<= 1e-6` prior to Go decimal quantization) AND passes Go's exact decimal hard-constraint verification after quantization.
- **Infeasible:** No allocation satisfies all hard constraints simultaneously. The system must return `status = INFEASIBLE` along with the specific conflicting constraint IDs and deficit magnitudes—never an arbitrary fallback allocation.
- **Solver Failure:** Timeouts, numerical divergence, process crashes, or invalid payloads from Python produce `status = SOLVER_FAILED` with sanitized diagnostics logged in `AuditEvent` and `OptimizationRun`. Authoritative balances remain untouched.

### 5.2 Approval Workflow State Machine

```
                  [Analyst Submits]
  +-------+      (Constraint Check OK)     +------------------+
  | DRAFT |------------------------------->| PENDING_APPROVAL |
  +-------+                                +------------------+
                                              |            |
                     [Approver Approves]      |            | [Approver Rejects]
                     (Re-verify Invariants)   v            v
                                        +----------+  +----------+
                                        | APPROVED |  | REJECTED |
                                        +----------+  +----------+
                                              |
                                              v
                                  [Human Executes Externally /
                                   Records Confirmation Event]
```

- **Confirmed Decision:** Transitioning to `APPROVED` triggers a **fresh Go-side re-verification** of available balances, reserve floors, and counterparty limits against current PostgreSQL state (preventing stale-snapshot approvals).
- **Confirmed Decision:** `APPROVED` means authorized by a human decision-maker for external execution or synthetic ledger simulation; QUANTA never dispatches real bank wires or market orders.

---

## 6. Decision Summary & Unresolved Questions

| Item | Classification | Notes |
| :--- | :--- | :--- |
| Fixed-point `NUMERIC` storage; no `float64` money | **Confirmed** | Enforced in PostgreSQL and Go |
| Explicit separation of Available, Operating, Emergency, Investable capital | **Confirmed** | Core domain invariants |
| Go-side re-verification at proposal creation AND approval | **Confirmed** | Prevents stale-state approval |
| `NUMERIC(20, 4)` + Banker's Rounding + cash residual rule | **Proposed** | To be finalized before Phase 1 migrations |

**Unresolved Questions:**
1. Which specific currency codes and minor-unit scales will synthetic scenarios support initially?
2. Should `TreasuryEntity` support multi-currency consolidated views (requiring FX rate snapshots) in Phase 1, or start single-currency and add FX later?
3. What exact approval expiry duration should move `PENDING_APPROVAL` to `EXPIRED`?
