# AI, Risk & Optimization Research Strategy — QUANTA

> **Document Status:** Phase 0 Draft — Pending Review  
> **Important:** All models, solvers, and libraries listed below are **research candidates**, not final implementation commitments. **No models or AI/ML libraries are installed or downloaded in Phase 0.**

---

## 1. Guiding Guardrails (Confirmed Decisions)

1. **Non-Authoritative AI:** Neither statistical models, ML predictors, quantum simulators, nor LLMs are authoritative for financial balances, constraint enforcement, or final approval. Go independently validates every numerical output.
2. **LLMs Never Compute Financial Math:** Language intelligence may summarize, explain, or retrieve context over Go-verified figures, but **must never** compute balances, risk metrics, or capital allocations.
3. **No Assumed Quantum Advantage:** Quantum and quantum-inspired solvers are exploratory research tracks. Every quantum formulation **must be benchmarked against classical baselines** on identical problem instances, reporting objective gap, feasibility rate, and wall-clock simulation cost honestly.
4. **Synthetic Data First:** Phase 1–2 experimentation uses reproducible, seeded synthetic treasury datasets with explicit assumptions.

---

## 2. Candidate Research Tracks

### 2.1 Cash-Flow Forecasting Candidates
Objective: Forecast inflows, outflows, and net operating liquidity with calibrated uncertainty intervals.

| Candidate | Category | Research Role |
| :--- | :--- | :--- |
| **Seasonal Naive** | Baseline | Mandatory sanity floor for all seasonal cash-flow series. |
| **ETS** (Error-Trend-Seasonality) | Classical Statistical | Interpretable level/trend/seasonal decomposition. |
| **ARIMA / SARIMAX** | Classical Statistical | Autoregressive baselines with optional exogenous drivers. |
| **XGBoost** | Gradient Boosted Trees | Tabular non-linear forecasting with engineered calendar/lag features. |
| **LightGBM** | Gradient Boosted Trees | Fast tabular forecasting and quantile interval estimation. |
| **Temporal Fusion Transformer (TFT)** | Deep Learning | Multi-horizon interpretable attention over mixed covariates. |
| **Chronos** | Foundation Time-Series | Zero-shot / fine-tuned probabilistic forecasting benchmark. |
| **TimesFM** | Foundation Time-Series | Zero-shot foundation time-series benchmark vs. classical/GBM baselines. |

### 2.2 Risk Modeling & Anomaly Detection Candidates
Objective: Quantify downside tail risk, liquidity stress impact, and anomalous treasury movements.

| Candidate | Category | Research Role |
| :--- | :--- | :--- |
| **Monte Carlo Simulation** | Stochastic Simulation | Correlated multi-factor portfolio & cash-flow path generation. |
| **Historical & Parametric VaR** | Tail Risk Metric | Baseline Value-at-Risk at standard confidence levels (e.g., 95%, 99%). |
| **CVaR (Expected Shortfall)** | Coherent Tail Risk | Captures expected loss beyond the VaR threshold; convex under LP reformulation. |
| **Stress Testing** | Scenario Analysis | Deterministic and macroeconomic shock replay against liquidity floors. |
| **Isolation Forest** | Unsupervised Anomaly | Flag unusual synthetic cash-flow spikes or balance-sheet outliers for human review. |

### 2.3 Classical Capital Optimization Candidates
Objective: Solve constrained capital allocation deterministically and reliably.

| Candidate | Category | Research Role |
| :--- | :--- | :--- |
| **Linear Programming (LP)** | Convex Exact | Fast continuous allocation and CVaR-constrained formulations. |
| **Quadratic Programming (QP)** | Convex Exact | Mean-variance / risk-penalized continuous allocation. |
| **MILP** | Discrete Exact | Ticket sizes, minimum lots, cardinality, and integer constraints. |
| **NSGA-II** | Multi-Objective Evolutionary | Pareto frontier exploration (return vs. risk vs. liquidity) when non-convex. |
| **HiGHS** | Open-Source Solver | High-performance LP/QP/MILP solver backend. |
| **OR-Tools** | Modeling & Solver Suite | Unified LP/MILP/CP-SAT modeling and solver interface. |
| **Pyomo** | Algebraic Modeling | Declarative mathematical optimization modeling in Python. |
| **CVXPY** | Convex Modeling | Disciplined convex programming (LP/QP/SOCP) abstraction. |

### 2.4 Quantum & Quantum-Inspired Research Candidates
Objective: Study QUBO encodings of discrete treasury allocation and benchmark objectively against classical solvers (Exact/MILP/SA).

| Candidate | Category | Research Role |
| :--- | :--- | :--- |
| **QUBO** | Problem Formulation | Quadratic Unconstrained Binary Optimization encoding budget, liquidity, and penalty terms. |
| **QAOA** | Variational Quantum Algorithm | Gate-based variational circuit benchmarked in classical simulation. |
| **Quantum-Inspired Optimization** | Classical Heuristic | Simulated annealing / tensor / Ising-inspired heuristics compared with MILP. |
| **PennyLane** | Quantum Framework | Differentiable quantum circuit prototyping and simulation. |
| **Qiskit** | Quantum Framework | QAOA circuit construction and local statevector/shot simulation. |
| **D-Wave Ocean** | Annealing / QUBO SDK | QUBO formulation tooling and classical simulated annealing samplers. |

### 2.5 Language Intelligence Candidates
Objective: Non-authoritative narrative explanation, report summarization, and policy/document retrieval.

| Candidate | Category | Research Role |
| :--- | :--- | :--- |
| **Qwen** | Open-Weight LLM | Local/self-hosted explanation and structured summary drafting. |
| **Llama** | Open-Weight LLM | Local/self-hosted narrative generation over verified JSON outputs. |
| **GPT** | Hosted LLM (Optional) | High-capability explanation drafting where external API use is permitted. |
| **BGE** | Embedding Model | Semantic retrieval over internal treasury policies and past ADRs/reports. |
| **E5** | Embedding Model | Alternative dense text embeddings for policy/audit retrieval. |

---

## 3. Evaluation & Benchmarking Protocol (Proposed)

- **Forecasting:** Compare every ML/foundation candidate against **Seasonal Naive** and **ETS/SARIMAX** using out-of-time rolling backtests (MAE, RMSE, pinball loss for quantiles).
- **Optimization:** Compare every heuristic and quantum candidate against **HiGHS / MILP** exact solutions on identical seeded instances (objective gap, constraint feasibility rate, runtime).
- **Language Intelligence:** Automated check verifying every numeric figure cited in generated explanations matches the Go-verified payload; reject or flag discrepancies.

---

## 4. Decision Summary & Unresolved Questions

| Item | Classification | Notes |
| :--- | :--- | :--- |
| Candidate-only status in Phase 0; zero installs/downloads | **Confirmed** | Strictly documentation phase |
| LLMs never authoritative for financial calculations | **Confirmed** | Hard architectural rule |
| Quantum advantage never assumed; classical benchmark required | **Confirmed** | Empirical evaluation only |
| Rolling out-of-time & exact-baseline benchmarking protocol | **Proposed** | Refined in Phase 2 |

**Unresolved Questions:**
1. Which classical solver interface (`CVXPY + HiGHS`, `OR-Tools`, or `Pyomo + HiGHS`) will serve as the primary Phase 2 baseline?
2. Which QAOA simulator (`Qiskit` vs `PennyLane` vs `D-Wave Ocean` samplers) will be evaluated first after classical baselines pass?
3. Will language intelligence run strictly offline (local open-weight models) or support optional external API configuration?
