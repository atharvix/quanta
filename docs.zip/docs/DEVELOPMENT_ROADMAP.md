# Development Roadmap — QUANTA

> **Document Status:** Phase 0 Draft — Pending Review  
> **Rule:** Implementation begins **only** after Phase 0 documentation is reviewed and approved.

---

## Phase 0 — Clean Architecture, Financial Correctness & Documentation (Current)
**Goal:** Establish a clean repository, authoritative domain definitions, Go/Python boundaries, native PostgreSQL design, and ADRs.
- **Deliverables:** `README.md`, `docs/*.md`, `docs/DECISIONS/ADR-001..004.md`.
- **Exit Gate:** Explicit human review and approval of all Phase 0 documents.

---

## Phase 1 — Go Core Foundation & Native PostgreSQL Ledger
**Goal:** Build the authoritative Go modular monolith and native Windows PostgreSQL schema.
- **Scope:**
  - Initialize clean Git repository and Go module (`go.mod`).
  - Native Windows PostgreSQL setup script and versioned SQL migrations (`NUMERIC(20, 4)` ledger & audit tables).
  - Exact decimal arithmetic package in Go (zero `float64` in monetary state).
  - Core modules: `treasury`, `ledger`, `constraints`, `exposure`, `governance` (approval state machine), `audit`, `auth` (RBAC).
  - Deterministic synthetic treasury data seeder.
- **Exit Gate:** Go unit & PostgreSQL integration tests pass, verifying conservation of capital, rounding reconciliation, maker-checker rules, and transactional audit logging.

---

## Phase 2 — Python Intelligence Service & Go/Python Contract Integration
**Goal:** Stand up the separate Python service with classical baselines first, integrated end-to-end with Go verification.
- **Scope:**
  - Implement versioned Go ↔ Python HTTP/JSON contract (`contract_version: "1.0"`, decimal string serialization, correlation IDs, timeouts).
  - Classical forecasting baselines (Seasonal Naive, ETS, SARIMAX) + synthetic backtest harness.
  - Risk analytics (Historical/Parametric VaR, CVaR, Monte Carlo, stress testing).
  - Classical optimization baseline (e.g., LP/QP/MILP via HiGHS / OR-Tools / CVXPY).
  - Go-side independent verification layer catching infeasible or invalid solver responses.
- **Exit Gate:** End-to-end tests proving Go rejects invalid Python outputs, handles solver timeouts gracefully, and enforces human approval before `APPROVED` state.

---

## Phase 3 — Advanced ML, Quantum Research Benchmarks & Non-Authoritative Narrative
**Goal:** Benchmark advanced research candidates rigorously against Phase 2 classical baselines.
- **Scope:**
  - ML & foundation forecasting experiments (XGBoost, LightGBM, TFT, Chronos/TimesFM) compared against Seasonal Naive & ETS.
  - Anomaly detection prototype (Isolation Forest) for synthetic cash-flow monitoring.
  - QUBO formulation & QAOA simulation benchmarked head-to-head against classical MILP/Exact baselines.
  - Optional non-authoritative LLM explanation drafting + embedding-based policy retrieval with strict numeric grounding checks.
- **Exit Gate:** Reproducible benchmark reports showing objective gaps, feasibility rates, and runtime trade-offs without unsubstantiated claims.

---

## Phase 4 — Web Frontend (Proposed: TypeScript + Svelte)
**Goal:** Build the human-in-the-loop treasury command center.
- **Scope (Proposed):**
  - TypeScript + SvelteKit interface consuming Go `/api/v1/*` endpoints.
  - Treasury balance & liquidity partition views (`Operating`, `Emergency`, `Investable`).
  - Approval queue UI for `Treasury_Approver` review (diff view, constraint audit, rationale entry).
  - Forecasting, risk stress-test, and Classical-vs-Quantum benchmark comparison views.
- **Exit Gate:** End-to-end browser workflows verified against native Windows Go + Python + PostgreSQL stack.

---

## Unresolved Questions
1. Should Phase 1 include a lightweight PowerShell CLI runner for exercising Go endpoints before Phase 4 UI exists?
2. Should Phase 3 quantum benchmarking be gated behind an optional Python extra/dependency group so core classical workflows remain lightweight?
