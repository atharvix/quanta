# Database Design — QUANTA

> **Document Status:** Phase 0 Draft — Pending Review  
> **Database Engine:** Native PostgreSQL on Windows (No Docker / No Containers).

---

## 1. Design Principles

1. **Confirmed Decision:** PostgreSQL is the sole authoritative persistence store, owned exclusively by the Go modular monolith. The Python intelligence service never connects directly to PostgreSQL to read or mutate financial records.
2. **Confirmed Decision:** Authoritative monetary amounts use fixed-point `NUMERIC` types—never `REAL`, `DOUBLE PRECISION`, or `FLOAT`.
3. **Confirmed Decision:** Financial history (`ledger_entries`, `audit_events`, `approval_decisions`) is **append-only**; corrections are recorded as offsetting entries rather than destructive `UPDATE` or `DELETE` operations.
4. **Proposed Decision:** Monetary amounts use `NUMERIC(20, 4)` (16 integer digits, 4 decimal places) and rates/ratios/weights use `NUMERIC(12, 6)`.

---

## 2. Logical Entity-Relationship Diagram

```
users (id, email, role, ...)
  |
  +---> approval_decisions (approver_id, decision, ...)
  +---> audit_events (actor_id, action, ...)

treasury_entities (id, name, base_currency, ...)
  |
  +---> treasury_accounts (id, entity_id, ledger_balance, encumbered_balance, ...)
  |       |
  |       +---> ledger_entries (id, account_id, delta_amount, balance_after, ...)
  |
  +---> liquidity_policies (id, entity_id, min_operating_liquidity, min_emergency_reserve, ...)
  +---> counterparties (id, entity_id, name, max_exposure_limit, ...)
  +---> financial_constraints (id, entity_id, constraint_type, parameters_json, ...)
  +---> optimization_runs (id, entity_id, status, problem_snapshot_json, raw_result_json, ...)
          |
          +---> allocation_proposals (id, run_id, status, verified_allocations_json, ...)
                  |
                  +---> approval_decisions (id, proposal_id, approver_id, decision, ...)
```

---

## 3. Core Tables (Conceptual Schema)

> Note: No SQL migration files are created in Phase 0. Column types below specify the Phase 1 target schema.

### 3.1 `treasury_entities` & `liquidity_policies`
- `treasury_entities`: `id (UUID PK)`, `name`, `is_synthetic (BOOLEAN)`, `created_at (TIMESTAMPTZ)`.
- `liquidity_policies`: `id (UUID PK)`, `treasury_entity_id (UUID FK)`, `min_operating_liquidity NUMERIC(20, 4)`, `min_emergency_reserve NUMERIC(20, 4)`, `effective_from (TIMESTAMPTZ)`, `created_by (UUID FK)`.
- **Constraint:** `min_operating_liquidity >= 0 AND min_emergency_reserve >= 0`.

### 3.2 `treasury_accounts` & `ledger_entries`
- `treasury_accounts`: `id (UUID PK)`, `treasury_entity_id (UUID FK)`, `account_code`, `currency_code (VARCHAR(10))`, `ledger_balance NUMERIC(20, 4)`, `encumbered_balance NUMERIC(20, 4)`, `version (BIGINT)` (optimistic concurrency), `updated_at (TIMESTAMPTZ)`.
- **Check Constraints:** `ledger_balance >= 0`, `encumbered_balance >= 0`, `encumbered_balance <= ledger_balance`.
- `ledger_entries` (append-only): `id (UUID PK)`, `account_id (UUID FK)`, `entry_type`, `delta_amount NUMERIC(20, 4)`, `balance_after NUMERIC(20, 4)`, `reference_type`, `reference_id (UUID)`, `correlation_id`, `created_at (TIMESTAMPTZ)`.

### 3.3 `counterparties` & `financial_constraints`
- `counterparties`: `id (UUID PK)`, `treasury_entity_id (UUID FK)`, `name`, `max_exposure_limit NUMERIC(20, 4) CHECK (max_exposure_limit >= 0)`, `current_exposure NUMERIC(20, 4) CHECK (current_exposure >= 0)`.
- `financial_constraints`: `id (UUID PK)`, `treasury_entity_id (UUID FK)`, `constraint_type`, `severity ('HARD' | 'SOFT')`, `parameters (JSONB)`, `is_active (BOOLEAN)`.

### 3.4 `optimization_runs`, `allocation_proposals` & `approval_decisions`
- `optimization_runs`: `id (UUID PK)`, `treasury_entity_id (UUID FK)`, `requested_by (UUID FK)`, `correlation_id`, `solver_category` (`'classical' | 'quantum_research' | 'hybrid_benchmark'`), `status` (`'COMPLETED' | 'INFEASIBLE' | 'SOLVER_FAILED' | 'VERIFICATION_FAILED'`), `problem_snapshot (JSONB)`, `raw_response (JSONB)`, `runtime_ms (INTEGER)`, `created_at (TIMESTAMPTZ)`.
- `allocation_proposals`: `id (UUID PK)`, `optimization_run_id (UUID FK)`, `treasury_entity_id (UUID FK)`, `status` (`'DRAFT' | 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED' | 'EXPIRED'`), `investable_capital NUMERIC(20, 4)`, `total_allocated NUMERIC(20, 4)`, `residual_cash NUMERIC(20, 4)`, `verified_allocations (JSONB)`, `submitted_by (UUID FK)`, `submitted_at (TIMESTAMPTZ)`, `expires_at (TIMESTAMPTZ)`.
- `approval_decisions` (append-only): `id (UUID PK)`, `proposal_id (UUID FK)`, `approver_id (UUID FK)`, `decision` (`'APPROVE' | 'REJECT'`), `rationale (TEXT)`, `balance_snapshot_at_decision (JSONB)`, `decided_at (TIMESTAMPTZ)`.

### 3.5 `users` & `audit_events`
- `users`: `id (UUID PK)`, `email (UNIQUE)`, `password_hash`, `full_name`, `role`, `is_active (BOOLEAN)`, `created_at (TIMESTAMPTZ)`.
- `audit_events` (append-only): `id (UUID PK)`, `actor_id (UUID NULLABLE)`, `actor_role`, `action`, `entity_type`, `entity_id`, `correlation_id`, `metadata (JSONB)`, `created_at (TIMESTAMPTZ)`.

---

## 4. Transactional & Concurrency Rules

- **Confirmed Decision:** Account balance changes, encumbrance holds, proposal approvals, and audit log insertions execute within a single ACID transaction in Go.
- **Proposed Decision:** Use `SELECT ... FOR UPDATE` or optimistic `version` checks on `treasury_accounts` and `allocation_proposals` during approval transitions to prevent double-allocation race conditions.
- **Proposed Decision:** Revoke `UPDATE` and `DELETE` privileges on `ledger_entries`, `approval_decisions`, and `audit_events` from the application database role once schema bootstrap completes.

---

## 5. Decision Summary & Unresolved Questions

| Item | Classification | Notes |
| :--- | :--- | :--- |
| Native Windows PostgreSQL owned solely by Go | **Confirmed** | See ADR-004 |
| Fixed-point `NUMERIC` storage & append-only ledger/audit tables | **Confirmed** | No binary floats |
| `NUMERIC(20, 4)` / `NUMERIC(12, 6)` scale & `JSONB` snapshots | **Proposed** | Confirm before Phase 1 DDL |
| Application role `REVOKE UPDATE/DELETE` on append-only tables | **Proposed** | Defense-in-depth |

**Unresolved Questions:**
1. Will multi-currency accounts require an explicit `fx_rate_snapshots` table in Phase 1, or is Phase 1 single-currency?
2. Should `problem_snapshot` and `raw_response` JSONB columns be compressed or archived after a retention threshold?
3. What Go migration tool (e.g., embedded SQL runner vs. `goose`/`golang-migrate`) will be adopted in Phase 1?
