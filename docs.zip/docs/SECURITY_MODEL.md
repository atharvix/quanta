# Security & Governance Model — QUANTA

> **Document Status:** Phase 0 Draft — Pending Review  
> **Core Principle:** Semi-autonomous financial governance—no single component, model, or unapproved actor may authorize consequential financial actions.

---

## 1. Trust Boundaries

```
[Human User / Browser]
        |  (Authenticated Session / Token)
        v
+-----------------------------------+
|  Go Core (Trusted Authority)      | <--- Enforces Auth, RBAC, Maker-Checker,
|  - Validates all inputs           |      Balance Invariants & Audit Logging
|  - Verifies all solver outputs    |
+-----------------------------------+
     |                        |
     | Trusted ACID DB        | Untrusted Compute Boundary
     v                        v
[PostgreSQL]           [Python Intelligence]
(Localhost)            (No DB Write Access, No Execution Authority)
```

- **Confirmed Decision:** Python intelligence output is treated as **advisory and untrusted** until Go verifies every numeric invariant and constraint.
- **Confirmed Decision:** QUANTA has **zero capability** to execute live bank transfers or market trades; approval authorizes a governance record only.

---

## 2. Authentication & Session Security

- **Proposed Decision (Phase 1):** Local user authentication backed by PostgreSQL (`users` table) using strong password hashing (`bcrypt` or `argon2id`) and signed short-lived JWTs (or HTTP-only secure cookies for the future Svelte UI).
- **Confirmed Decision:** Passwords and secrets are never hardcoded in source control and never logged in audit metadata.
- **Proposed Decision:** Production/enterprise deployments later may integrate corporate SSO/OIDC without altering internal RBAC or maker-checker enforcement.

---

## 3. Role-Based Access Control (RBAC) — Proposed Matrix

| Capability | `Viewer / Auditor` | `Treasury_Analyst` | `Treasury_Approver` | `Admin` |
| :--- | :---: | :---: | :---: | :---: |
| View balances, positions, runs, proposals | Yes | Yes | Yes | Yes |
| View immutable `audit_events` | Yes | No *(or scoped)* | Yes | Yes |
| Run forecasts, risk simulations, optimizations | No | Yes | Yes | No *(separation)* |
| Submit `AllocationProposal` for approval | No | Yes | No *(maker)* | No |
| Approve / Reject `PENDING_APPROVAL` proposal | No | No | Yes *(checker)* | No |
| Modify policy thresholds / constraints | No | Propose | Approve | No |
| Manage users & role assignments | No | No | No | Yes |

*(Proposed separation: `Admin` manages accounts/roles, not financial approvals, preventing privilege escalation into treasury sign-off.)*

---

## 4. Maker-Checker & Approval Integrity

- **Proposed Decision:** **Four-Eyes (Maker-Checker) Principle:** The `submitted_by` user ID on an `AllocationProposal` cannot equal the `approver_id` on `ApprovalDecision`.
- **Confirmed Decision:** Every approval executes inside a Go-managed PostgreSQL transaction that:
  1. Locks the proposal and relevant `treasury_accounts`.
  2. Re-computes `available_balance`, `operating_liquidity`, `emergency_reserve`, and `counterparty_exposure` against current database state.
  3. Rejects stale or constraint-violating approvals cleanly.
  4. Writes an immutable `ApprovalDecision` and `AuditEvent` in the same transaction.

---

## 5. Auditability & Tamper-Evidence

**Confirmed Decision:**  
All consequential events emit an append-only `audit_events` record containing:
- `event_id`, `created_at` (UTC), `correlation_id`
- `actor_id`, `actor_role`
- `action` (e.g., `optimization.requested`, `proposal.submitted`, `proposal.approved`, `proposal.rejected`, `constraint.updated`, `auth.login_failed`)
- `entity_type`, `entity_id`
- `metadata` (sanitized summary—no secrets or raw credentials)

**Proposed Decision:** Restrict application database role permissions so `audit_events`, `ledger_entries`, and `approval_decisions` allow `INSERT` and `SELECT` only (no `UPDATE` or `DELETE`).

---

## 6. Decision Summary & Unresolved Questions

| Item | Classification | Notes |
| :--- | :--- | :--- |
| Human approval required for consequential actions | **Confirmed** | Core semi-autonomous safeguard |
| Go verifies Python outputs before persistence/approval | **Confirmed** | Untrusted compute boundary |
| Append-only audit trail for all state & governance changes | **Confirmed** | Committed in same DB transaction |
| 4-role RBAC & Maker-Checker separation | **Proposed** | Needs confirmation for single-user local dev mode |

**Unresolved Questions:**
1. In local single-developer testing, should a development toggle allow single-user maker-checker bypass (clearly flagged in audit logs), or require two seeded test accounts?
2. Should Go ↔ Python localhost calls require a shared internal secret header?
3. What password complexity, lockout, and token expiry defaults should be enforced in Phase 1?
