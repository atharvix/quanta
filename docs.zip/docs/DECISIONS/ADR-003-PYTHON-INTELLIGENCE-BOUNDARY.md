# ADR-003: Separate Python Intelligence Boundary

- **Status:** Confirmed (Boundary) / Proposed (HTTP+JSON Localhost Transport)
- **Date:** Phase 0 (2026-11-27)
- **Deciders:** QUANTA Architecture Team

---

## Context
QUANTA requires statistical forecasting, Monte Carlo/VaR/CVaR risk simulation, mathematical optimization (LP/QP/MILP), quantum/quantum-inspired benchmarking (QUBO/QAOA), and optional non-authoritative language intelligence. Python is the standard ecosystem for these workloads, while Go owns authoritative financial state.

## Decision
Run intelligence and optimization in a **separate, stateless Python service** communicating with Go over an **explicit, versioned contract** (`contract_version`, correlation IDs, timeouts, and exact decimal strings for money).

## Boundary Rules (Confirmed)
1. **Python is Non-Authoritative:** Python never owns system-of-record state and never writes directly to PostgreSQL financial tables.
2. **Go Owns Verification:** Every candidate allocation or risk/forecast output returned by Python is validated by Go against exact decimal conservation, liquidity floors, and counterparty caps before persistence or human approval.
3. **LLMs Are Strictly Advisory:** Language models never calculate balances, risk metrics, or allocations.
4. **Fail-Safe Degradation:** If Python is unavailable, times out, or fails to converge, Go logs the failure and preserves authoritative treasury state untouched.

## Trade-offs & Mitigations
- **Trade-off:** Serialization overhead and process boundary between Go and Python.
  - **Mitigation:** Send compact self-contained problem snapshots over localhost (`127.0.0.1`); use explicit timeouts and decimal string encoding to prevent JSON float drift.
- **Trade-off:** Two local runtimes to manage (Go + Python).
  - **Mitigation:** Clean PowerShell start/stop scripts in later implementation phases keep native Windows startup trivial.

## Alternatives Considered
- **Embedding Python via CGo:** Rejected due to GIL/memory complexity, brittle Windows build tooling, and crash isolation risks.
- **Implementing all solvers in Go:** Rejected because mature optimization, forecasting, and quantum research libraries live in Python.
