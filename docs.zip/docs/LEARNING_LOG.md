# Learning & Engineering Log — QUANTA

> **Purpose:** Record architectural lessons, financial systems engineering trade-offs, and key insights across phases so design rationale remains transparent.

---

## Phase 0 — Clean-Slate Architecture & Financial Correctness

### 1. Why Start From Zero Instead of Patching Legacy?
- Carrying forward legacy code, implicit schemas, or ad-hoc infrastructure creates hidden coupling and subtle correctness bugs.
- Starting from zero in Phase 0 lets us establish **authoritative invariants first**—monetary precision, explicit Go/Python boundaries, native PostgreSQL ownership, and semi-autonomous approval gates—before writing a single line of application code.

### 2. Monetary Representation: Why Binary Floating-Point Fails Treasury Systems
- IEEE 754 `float64` cannot represent base-10 fractions like `0.1` or `0.01` exactly. Over repeated ledger summations, reserve checks, and allocation rounding, binary representation drift causes conservation-of-capital checks (`sum(allocations) + cash == total`) to fail unpredictably.
- **Takeaway:** Store monetary balances in PostgreSQL as fixed-point `NUMERIC`, use exact decimal arithmetic in Go, serialize money as decimal strings across the Go ↔ Python boundary, and assign any solver quantization residual explicitly to unallocated cash.

### 3. Untrusted Intelligence Boundary
- Numerical optimizers (LP/QP/MILP/QAOA), ML forecasters, and LLMs optimize approximations or generate stochastic outputs; they are not ledger engines.
- **Takeaway:** Treating Python outputs as **candidate proposals** that Go must independently verify before persistence or human approval prevents solver tolerance drift, infeasibility masking, or LLM hallucination from corrupting authoritative treasury state.

### 4. Empirical Discipline for AI & Quantum Claims
- Complex ML models (TFT, foundation models) and quantum algorithms (QUBO/QAOA) are only valuable if they beat or complement simple classical baselines (`Seasonal Naive`, `ETS`, `HiGHS/MILP`) under honest, seeded evaluation.
- **Takeaway:** Every advanced model must be benchmarked against classical baselines on identical synthetic inputs with runtime and feasibility reported transparently.

### 5. Simplicity in Infrastructure
- Running PostgreSQL, Go, and Python natively on Windows with PowerShell eliminates container networking overhead, image build friction, and premature microservice coordination during foundational development.
