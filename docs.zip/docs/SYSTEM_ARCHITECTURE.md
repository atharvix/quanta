# System Architecture — QUANTA

> **Document Status:** Phase 0 Draft — Pending Review  
> **Architecture Style:** Go Modular Monolith + Separate Python Intelligence Service + Native PostgreSQL on Windows.

---

## 1. High-Level Component Architecture

```
+-----------------------------------------------------------------------+
|                Future Frontend (Proposed: TypeScript + Svelte)        |
|                     Localhost UI (Human Review & Lab)                 |
+-----------------------------------------------------------------------+
                                    |
                                    | HTTPS / REST JSON (Localhost)
                                    v
+-----------------------------------------------------------------------+
|                  Go Core Backend (Modular Monolith)                   |
|  Authoritative Records · Business Rules · Approvals · Audit Trail     |
|                                                                       |
|  +--------------+  +---------------+  +------------+  +------------+  |
|  |   Treasury   |  |  Constraints  |  |  Approval  |  |   Audit    |  |
|  |   & Ledger   |  |  & Exposure   |  |  Workflow  |  |   Trail    |  |
|  +--------------+  +---------------+  +------------+  +------------+  |
|  +--------------+  +---------------+  +------------+                  |
|  | Auth & RBAC  |  |  Orchestrator |  |  Decimal   |                  |
|  |              |  |  & Verifier   |  |  Math Core |                  |
|  +--------------+  +---------------+  +------------+                  |
+-----------------------------------------------------------------------+
         |                                           |
         | SQL (pgx / database/sql)                  | HTTP + JSON Contract
         | ACID Transactions                         | (Timeouts + Correlation ID)
         v                                           v
+---------------------------+       +-----------------------------------+
|   Native PostgreSQL       |       |   Python Intelligence Service     |
|   (Windows Service)       |       |   (Stateless / Non-Authoritative) |
|                           |       |                                   |
| - Authoritative Balances  |       | - Cash-Flow Forecasting           |
| - Constraints & Policies  |       | - Risk & Stress Simulation        |
| - Proposals & Approvals   |       | - Classical & QUBO/QAOA Solvers   |
| - Append-Only Audit Logs  |       | - Non-Authoritative LLM Narrator  |
+---------------------------+       +-----------------------------------+
```

---

## 2. Architectural Principles

### 2.1 Go Modular Monolith (Authoritative Core)
**Confirmed Decision:**  
All authoritative state, business invariants, and persistence live in a single Go binary structured into cohesive internal modules (`treasury`, `ledger`, `constraints`, `exposure`, `governance`, `audit`, `auth`, `intelligence_client`).
- Modules communicate via explicit Go interfaces and domain structs in-process.
- Cross-module state changes (e.g., approving an allocation + reserving funds + writing an audit event) execute inside a **single PostgreSQL ACID transaction**.
- **Rationale:** Eliminates distributed transactions, network hops between core financial modules, and premature microservice complexity (see [ADR-002](DECISIONS/ADR-002-MODULAR-MONOLITH.md)).

### 2.2 Separate Python Intelligence Service (Advisory / Compute Boundary)
**Confirmed Decision:**  
Forecasting, risk simulation, optimization solvers, quantum research prototypes, and optional language intelligence run in a separate Python service.
- **Stateless Compute:** Python does **not** hold the system of record and does **not** connect directly to PostgreSQL to mutate financial state.
- **Input:** Go sends an explicit, self-contained problem snapshot (balances, constraints, horizon, seed, parameters) with exact decimal strings.
- **Output:** Python returns structured predictions, risk distributions, or candidate allocations with solver metadata (`solver_id`, `feasible`, `runtime_ms`, `warnings`).
- **Verification Gate:** Go treats Python output as an **untrusted candidate proposal** until Go independently verifies conservation of capital, decimal rounding, liquidity floors, and counterparty limits (see [ADR-003](DECISIONS/ADR-003-PYTHON-INTELLIGENCE-BOUNDARY.md)).

### 2.3 Native Windows + PowerShell Runtime (No Containers)
**Confirmed Decision:**  
All components run natively on Windows:
- PostgreSQL runs as a native Windows service on `localhost`.
- Go backend runs natively as a compiled Go executable / `go run`.
- Python intelligence service runs in a local Python virtual environment.
- No Docker, Docker Compose, or Kubernetes is used.

---

## 3. End-to-End Request & Verification Flow

1. **Trigger:** Analyst requests an optimization or risk evaluation via Go REST API.
2. **Snapshot & Policy Load (Go):** Go reads authoritative balances, reserve policies, counterparty exposures, and constraints from PostgreSQL.
3. **Contract Dispatch (Go → Python):** Go computes `investable_capital` and dispatches an explicit `OptimizationProblem` payload with a `X-Correlation-ID` and strict timeout.
4. **Compute (Python):** Python runs the requested solver(s) (and classical baseline if benchmarking quantum) and returns candidate weights/amounts + feasibility diagnostics.
5. **Independent Verification (Go):** Go quantizes values using exact decimal rules, reconciles residual cash, and checks every hard constraint.
6. **Persist & Govern (Go → PostgreSQL):** Go stores the `OptimizationRun`, creates a `DRAFT` or `PENDING_APPROVAL` `AllocationProposal`, and appends an `AuditEvent`.
7. **Human Approval (Go):** An authorized Approver reviews the proposal; Go re-verifies constraints against live balances inside a DB transaction before marking `APPROVED`.

---

## 4. Failure Modes & Resilience

| Failure Scenario | System Behavior | Financial Safety Guarantee |
| :--- | :--- | :--- |
| **Python service down / unreachable** | Go returns `503 Service Unavailable` for new compute requests; records failure audit event. | Core treasury viewing, balances, and approvals remain operational; balances untouched. |
| **Python solver timeout or crash** | Go cancels context at timeout, records `SOLVER_FAILED` in `OptimizationRun`. | No partial or unverified proposal is created. |
| **Python returns infeasible or subtly invalid math** | Go verifier catches violation, marks run `VERIFICATION_FAILED` / `INFEASIBLE` with diagnostics. | Invalid allocations can never enter `PENDING_APPROVAL` or `APPROVED`. |
| **PostgreSQL unavailable** | Go fails readiness check and rejects mutations cleanly with `503`. | No split-brain or in-memory-only financial state. |

---

## 5. Decision Summary & Unresolved Questions

| Item | Classification | Notes |
| :--- | :--- | :--- |
| Go modular monolith owning all authoritative state | **Confirmed** | See ADR-001 & ADR-002 |
| Separate stateless Python intelligence service | **Confirmed** | See ADR-003 |
| Native Windows PostgreSQL & zero containers | **Confirmed** | See ADR-004 |
| Synchronous HTTP/JSON on localhost between Go and Python | **Proposed** | Add async job queue only if solver runtimes exceed HTTP timeouts |
| TypeScript + Svelte frontend | **Proposed** | Deferred until backend/intelligence contracts stabilize |

**Unresolved Questions:**
1. Should long-running Monte Carlo or multi-solver benchmark sweeps use an asynchronous Go-managed job status pattern (`202 Accepted` + polling) from Phase 2 onward?
2. Should the Python service expose a single unified endpoint per capability or separate endpoints for classical vs. quantum benchmark runs?
